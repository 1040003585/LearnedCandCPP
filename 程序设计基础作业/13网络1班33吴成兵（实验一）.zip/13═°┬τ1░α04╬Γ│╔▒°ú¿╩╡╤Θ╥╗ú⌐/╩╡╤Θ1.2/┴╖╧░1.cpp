#include<stdio.h>
int main()
{
	int a,b,sum;
	printf("������a,b\n");
	scanf("%d,%d",&a,&b);
	sum=a+b;
	printf("sum=%d\n",sum);
	return 0;
}