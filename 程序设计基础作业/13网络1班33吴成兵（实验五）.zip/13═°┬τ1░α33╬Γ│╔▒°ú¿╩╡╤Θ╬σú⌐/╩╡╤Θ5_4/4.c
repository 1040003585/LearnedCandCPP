#include<stdio.h>
int main()
{
	float x;
	2*x*x*x-4*x*x+3*x-6==0;
	printf("%6.2f\n",x);
	return 0;
}